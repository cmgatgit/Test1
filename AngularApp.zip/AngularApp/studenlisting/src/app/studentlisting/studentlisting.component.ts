import { Component } from '@angular/core';
@Component({
  selector: 'app-studentlisting',
  templateUrl: './studentlisting.component.html',
  styleUrls: ['./studentlisting.component.css']
})
export class StudentlistingComponent {
  

}
