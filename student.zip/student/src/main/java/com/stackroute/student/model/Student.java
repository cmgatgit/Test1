package com.stackroute.student.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

// annotate the student class with @Entity, @Id
@Entity
public class Student {

//    declare the variable studentID, studentName, studentAge, studentGender, studentCity

    @Id
    private int studentID;
    private String studentName;
    private int studentAge;
    private String studentGender;
    private String studentCity;

//    generate default constructor, param constructor, getter, setter, toString methods
public Student() {
    }

    public Student(int studentID, String studentName, int studentAge, String studentGender, String studentCity) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.studentAge = studentAge;
        this.studentGender = studentGender;
        this.studentCity = studentCity;
    }

    public int getStudentID() {
        return studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getStudentGender() {
        return studentGender;
    }

    public String getStudentCity() {
        return studentCity;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentAge(int studentAge) {
        this.studentAge = studentAge;
    }

    public void setStudentGender(String studentGender) {
        this.studentGender = studentGender;
    }

    public void setStudentCity(String studentCity) {
        this.studentCity = studentCity;
    }

    @Override
    public String toString() {
        return "Student{" + "studentID=" + studentID + ", studentName=" + studentName + ", studentAge=" + studentAge + ", studentGender=" + studentGender + ", studentCity=" + studentCity + '}';
    }

}
