package com.stackroute.student.exception;

// create StudentAlreadyExistsException which extends Exception
public class StudentAlreadyExistsException extends Exception {
    public StudentAlreadyExistsException(String message) {
        super(message);
    }
}
