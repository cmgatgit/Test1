package com.stackroute.student.controller;

// import all the required classes
import com.stackroute.student.exception.StudentAlreadyExistsException;
import com.stackroute.student.exception.StudentNotExistsException;
import com.stackroute.student.model.Student;
import com.stackroute.student.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// create class StudentController
@RestController
@RequestMapping("/api/v1")
public class StudentController {

//    autowire StudentService class
    @Autowired
    private StudentService studentService;

//    create method to store student details in database
//    use try catch block to handle exception and throw StudentAlreadyExistsException
//    if student already exists
    @PostMapping("/student")
    public void saveStudent(@RequestBody Student student) throws StudentAlreadyExistsException {
        try
        {
            studentService.saveStudent(student);
        }
        catch (Exception e)
        {
            throw new StudentAlreadyExistsException("Student already exists");
        }
    }

//    create method to get all students from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
    @GetMapping("/students")
    public List<Student> getAllStudents() throws StudentNotExistsException {
        try
        {
            return (List<Student>) studentService.getAllStudents();
        }
        catch (Exception e)
        {
            throw new StudentNotExistsException("Student does not exists");
        }
    }

//    create method to get student by id from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
    @GetMapping("/student/{id}")
    public Student getStudentById(@PathVariable int id) throws StudentNotExistsException {
        try
        {
            return studentService.getStudentById(id);
        }
        catch (Exception e)
        {
            throw new StudentNotExistsException("Student does not exists");
        }
    }

//    create method to delete student by id from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
    @DeleteMapping("/student/{id}")
    public void deleteStudentById(@PathVariable int id) throws StudentNotExistsException {
        try
        {
            studentService.deleteStudentById(id);
        }
        catch (Exception e)
        {
            throw new StudentNotExistsException("Student does not exists");
        }
    }

//    create method to update student by id from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
    @PutMapping("/student/{id}")
    public void updateStudentById(@RequestBody Student student, @PathVariable int id) throws StudentNotExistsException {
        try
        {
            studentService.updateStudentById(student, id);
        }
        catch (Exception e)
        {
            throw new StudentNotExistsException("Student does not exists");
        }
    }




}
