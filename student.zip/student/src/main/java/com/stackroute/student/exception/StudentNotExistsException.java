package com.stackroute.student.exception;

// create class StudentAlreadyExistsException which extends Exception
public class StudentNotExistsException extends Exception{
    public StudentNotExistsException(String message) {
        super(message);
    }
}
