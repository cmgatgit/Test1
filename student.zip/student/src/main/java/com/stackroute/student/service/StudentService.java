package com.stackroute.student.service;

import com.stackroute.student.exception.StudentAlreadyExistsException;
import com.stackroute.student.model.Student;
import com.stackroute.student.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentService {

//    autowire StudentRepo class

    @Autowired
    private StudentRepo studentRepo;

//     create method to store student details in database
//    use save() method of StudentRepo class
//    use try catch block to handle exception and throw StudentAlreadyExistsException
//    if student already exists
    public void saveStudent(Student student) throws StudentAlreadyExistsException{
        try
        {
            studentRepo.save(student);
        }
        catch (Exception e)
        {
            throw new StudentAlreadyExistsException("Student already exists");
        }
    }

//    create method to get all students from database
//    use findAll() method to get all students from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
    public Iterable<Student> getAllStudents() throws StudentAlreadyExistsException{
        try
        {
            return studentRepo.findAll();
        }
        catch (Exception e)
        {
            throw new StudentAlreadyExistsException("Student does not exists");
        }
    }

//    create method to get student by id from database
//    use findById() method to get student by id from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
    public Student getStudentById(int id) throws StudentAlreadyExistsException{
        try
        {
            return studentRepo.findById(id).get();
        }
        catch (Exception e)
        {
            throw new StudentAlreadyExistsException("Student does not exists");
        }
    }

//    create method to delete student by id from database
//    use deleteById() method to delete student by id from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
    public void deleteStudentById(int id) throws StudentAlreadyExistsException{
        try
        {
            studentRepo.deleteById(id);
        }
        catch (Exception e)
        {
            throw new StudentAlreadyExistsException("Student does not exists");
        }
    }

//    create method to update student by id from database
//    use save() method to update student by id from database
//    use try catch block to handle exception and throw StudentNotExistsException
//    if student does not exists
   public void updateStudentById(Student student, int id) throws StudentAlreadyExistsException{
//        retrieve the existing student entity by ID
       Optional<Student> optionalStudent = studentRepo.findById(id);
       if (optionalStudent.isPresent()){
           Student existingStudent1 = optionalStudent.get();
              existingStudent1.setStudentName(student.getStudentName());
                existingStudent1.setStudentAge(student.getStudentAge());
                existingStudent1.setStudentGender(student.getStudentGender());
                existingStudent1.setStudentCity(student.getStudentCity());
                studentRepo.save(existingStudent1);

       }else {
           throw new StudentAlreadyExistsException("Student does not exists");
       }

    }




}
